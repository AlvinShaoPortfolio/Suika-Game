using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PreDropDisplay : MonoBehaviour
{

    [SerializeField] Sprite [] CircleImages;
    [SerializeField] SpriteRenderer spriteRenderer;

    public GameObject mouseTarget;
    public bool Fired = false;
    int circleDrop = 1;

    void Update(){
        if(Fired == true){
            circleDrop = mouseTarget.GetComponent<DropCircle>().circleDrop1;
            Fired = false;
        }
        if(circleDrop == 1){
            spriteRenderer.sprite = CircleImages[0];
        }
        else if(circleDrop == 2){
            spriteRenderer.sprite = CircleImages[1];
        }
        else if(circleDrop == 3){
            spriteRenderer.sprite = CircleImages[2];
        }
        else if(circleDrop == 4){
            spriteRenderer.sprite = CircleImages[3];
        }
        else{
            spriteRenderer.sprite = CircleImages[4];
        }
    }
}
