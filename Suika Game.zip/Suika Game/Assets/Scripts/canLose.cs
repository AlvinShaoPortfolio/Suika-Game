using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class canLose : MonoBehaviour
{
    public bool Loseable = false;

    public void OnCollisionEnter2D(Collision2D collision){
        Loseable = true;
    }
}
