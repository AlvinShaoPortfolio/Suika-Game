using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointHolder : MonoBehaviour
{
    public float Points = 0;
    public GameObject GO;

    void Start(){
        Points = 0;
    }

    void Update(){
        if(GO.GetComponent<LoseCondition>().newGame == true){
            Points = 0;
            GO.GetComponent<LoseCondition>().newGame = false;
        }
    }
}
