using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoseCondition : MonoBehaviour
{
    public bool newGame = false;

    void OnTriggerEnter2D(Collider2D hitInfo){
        canLose lost = hitInfo.GetComponent<canLose>();
        if((lost.Loseable) == true){
            newGame = true;
            SceneManager.LoadScene(2);
        }
    }
}
