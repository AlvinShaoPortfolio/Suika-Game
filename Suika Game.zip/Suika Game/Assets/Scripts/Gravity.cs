using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gravity : MonoBehaviour
{
    public Rigidbody2D rb;
    
    // Update is called once per frame
    void Update(){
        rb.gravityScale = 8;
    }

    public void OnCollisionEnter2D(Collision2D collision){
        GetComponent<Gravity>().enabled = false;
    }

}
