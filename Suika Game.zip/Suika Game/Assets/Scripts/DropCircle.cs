using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DropCircle : MonoBehaviour
{
    public Transform MouseTarget;
    public GameObject circlePrefab;
    public GameObject circlePrefab1;
    public GameObject circlePrefab2;
    public GameObject circlePrefab3;
    public GameObject circlePrefab4;
    public GameObject CircleUnderCarrier;
    public GameObject Display2nd;

    // Update is called once per frame

    public float dropRate = 2f;
    float nextDropTime = 0f;
    int rand = 0;
    public int circleDrop1;
    public int circleDrop2;
    bool firstDrop = true;

    void Update(){
        if(Time.time > nextDropTime){
            if(Input.GetButtonDown("Fire1")){
                CircleUnderCarrier.GetComponent<PreDropDisplay>().Fired = true; 
                Display2nd.GetComponent<Display2nd>().Fired = true; 
                if(firstDrop){
                    circleDrop1 = 1;
                    circleDrop2 = 2;
                    firstDrop = false;
                }

                if(circleDrop1 ==1){
                    Instantiate(circlePrefab, MouseTarget.position, MouseTarget.rotation);
                }
                else if(circleDrop1 == 2){
                    Instantiate(circlePrefab1, MouseTarget.position, MouseTarget.rotation);

                }
                else if(circleDrop1 == 3){
                    Instantiate(circlePrefab2, MouseTarget.position, MouseTarget.rotation);
                }
                else if(circleDrop1 == 4){
                    Instantiate(circlePrefab3, MouseTarget.position, MouseTarget.rotation);
                }
                else{
                    Instantiate(circlePrefab4, MouseTarget.position, MouseTarget.rotation);
                }
                nextDropTime = Time.time + 1f / dropRate;
                circleDrop1 = circleDrop2;
                rand = Random.Range(1,100);
                if(rand >= 1 && rand <= 30){
                    circleDrop2 = 1;
                }
                else if(rand >= 31 && rand <= 55){
                    circleDrop2 = 2;
                }
                else if(rand >= 56 && rand <= 75){
                    circleDrop2 = 3;
                }
                else if(rand>=76 && rand <= 90){
                    circleDrop2 = 4;
                }
                else{
                    circleDrop2 = 5;
                }
            }
        }
    }
}
