using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Points : MonoBehaviour{

    public GameObject Point;
    public TMP_Text messageText;

    void Update(){
        messageText.SetText(Point.GetComponent<PointHolder>().Points.ToString());
    }

}
