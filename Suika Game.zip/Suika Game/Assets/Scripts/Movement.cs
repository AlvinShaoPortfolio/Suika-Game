using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour{
    public Rigidbody2D rb;

    void Update()
    {
        if(Input.GetKey(KeyCode.A) && transform.position.x-.02f > -9.5f){
            transform.position = new Vector2(transform.position.x-.02f, transform.position.y-(.05f * (rb.gravityScale/2)));
        }

        if(Input.GetKey(KeyCode.D) && transform.position.x-.02f < 9.5f){
            transform.position = new Vector2(transform.position.x+.02f, transform.position.y-(.05f * (rb.gravityScale/2)));
        }
    }

    public void OnCollisionEnter2D(Collision2D collision){
        GetComponent<Movement>().enabled = false;
    }
}
