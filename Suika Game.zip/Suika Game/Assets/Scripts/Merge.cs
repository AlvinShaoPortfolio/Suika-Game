using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Merge : MonoBehaviour
{
    public GameObject PointHolder;
    public GameObject nextCirclePrefab;
    public string circleID;
    public bool triggered = false;

    public void OnCollisionEnter2D(Collision2D collision){
        Merge otherCircle = collision.gameObject.GetComponent<Merge>();
        if(circleID != "Circle10"){
            if(otherCircle != null && otherCircle.circleID == circleID && triggered == false){
                triggered = true;
                Destroy(gameObject);
                Vector2 midPoint = (transform.position + otherCircle.transform.position)/2;
                if(transform.position.x > otherCircle.transform.position.x){
                    Instantiate(nextCirclePrefab, midPoint, Quaternion.identity);
                }
                else if(transform.position.x == otherCircle.transform.position.x){
                    if(transform.position.y > otherCircle.transform.position.y){
                        Instantiate(nextCirclePrefab, midPoint, Quaternion.identity);
                    }
                }
                if(circleID == "Circle1"){
                    PointHolder.GetComponent<PointHolder>().Points = PointHolder.GetComponent<PointHolder>().Points + .5f;
                }
                else if(circleID == "Circle2"){
                    PointHolder.GetComponent<PointHolder>().Points = PointHolder.GetComponent<PointHolder>().Points + 1.5f;
                }
                else if(circleID == "Circle3"){
                    PointHolder.GetComponent<PointHolder>().Points = PointHolder.GetComponent<PointHolder>().Points + 3;
                }
                else if(circleID == "Circle4"){
                    PointHolder.GetComponent<PointHolder>().Points = PointHolder.GetComponent<PointHolder>().Points + 5;
                }
                else if(circleID == "Circle5"){
                    PointHolder.GetComponent<PointHolder>().Points = PointHolder.GetComponent<PointHolder>().Points + 7.5f;
                }
                else if(circleID == "Circle6"){
                    PointHolder.GetComponent<PointHolder>().Points = PointHolder.GetComponent<PointHolder>().Points + 10.5f;
                }
                else if(circleID == "Circle7"){
                    PointHolder.GetComponent<PointHolder>().Points = PointHolder.GetComponent<PointHolder>().Points + 14;
                }
                else if(circleID == "Circle8"){
                    PointHolder.GetComponent<PointHolder>().Points = PointHolder.GetComponent<PointHolder>().Points + 18;
                }
                else if(circleID == "Circle9"){
                    PointHolder.GetComponent<PointHolder>().Points = PointHolder.GetComponent<PointHolder>().Points + 22.5f;
                }
            }
        }
        else{
            if(otherCircle != null && otherCircle.circleID == circleID && triggered == false){
                triggered = true;
                Destroy(gameObject);
                PointHolder.GetComponent<PointHolder>().Points = PointHolder.GetComponent<PointHolder>().Points + 55;
            }
        }
    }
}

